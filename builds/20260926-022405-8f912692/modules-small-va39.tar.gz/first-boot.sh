#!/bin/sh
# first-boot VA39 module bring-up — topo order generated 2026-09-15
set -e
D=/root/deploy-va39
dmesg -n 7
mkdir -p /lib/firmware/powervr && cp $D/firmware/*.fw /lib/firmware/powervr/
insmod $D/rfkill.ko
insmod $D/cfg80211.ko
insmod $D/aic_load_fw.ko
insmod $D/aic8800_fdrv.ko
insmod $D/backlight.ko
insmod $D/drm_panel_orientation_quirks.ko
insmod $D/drm.ko
insmod $D/drm_exec.ko
insmod $D/drm_gpuvm.ko
insmod $D/drm_kms_helper.ko
insmod $D/drm_shmem_helper.ko
insmod $D/gpu-sched.ko
insmod $D/libarc4.ko
insmod $D/mac80211.ko
insmod $D/powervr.ko
echo "== lsmod =="; lsmod | head -20
echo "== dri =="; ls -la /dev/dri/ 2>&1 || true
echo "== wifi =="; ip link 2>&1 | head; dmesg | tail -40
